package com.keyin;

import java.util.Scanner;

public class Library {

    // Arrays to store book attributes
    private String[] titles;
    private String[] authors;
    private String[] isbns;
    private boolean[] availability;

    // Constructor that accepts book information arrays
    public Library(String[] titles, String[] authors, String[] isbns, boolean[] availability) {
        this.titles = titles;
        this.authors = authors;
        this.isbns = isbns;
        this.availability = availability;
    }

    public Library(int initialCapacity) {
        // Initialize arrays with the given initial capacity
        titles = new String[initialCapacity];
        authors = new String[initialCapacity];
        isbns = new String[initialCapacity];
        availability = new boolean[initialCapacity];
    }

    public void run() {
        Scanner scanner = new Scanner(System.in);

        // Main program loop to display the menu and to process the user input
        while (true) {
            displayMenu();  // Display the menu options
            int choice = scanner.nextInt();  // Read user choice
            scanner.nextLine();  // Consume newline

            switch (choice) {
                case 1:
                    searchForBook(scanner);  // Execute book search functionality
                    break;
                case 2:
                    checkoutBook(scanner);  // Execute book checkout functionality
                    break;
                case 3:
                    returnBook(scanner);  // Execute book return functionality
                    break;
                case 4:
                    System.out.println("Exiting program. Goodbye!");
                    scanner.close();
                    return;  // Exit the program
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private void displayMenu() {
        // Display the menu options
        System.out.println("\nMenu:");
        System.out.println("1. Search for a book");
        System.out.println("2. Checkout a book");
        System.out.println("3. Return a book");
        System.out.println("4. Exit");
        System.out.print("Enter your choice: ");
    }

    private void searchForBook(Scanner scanner) {
        System.out.print("Enter book title, author, or ISBN: ");
        String searchQuery = scanner.nextLine().toLowerCase();

        boolean found = false;
        for (int i = 0; i < titles.length; i++) {
            if (titles[i].toLowerCase().contains(searchQuery)
                    || authors[i].toLowerCase().contains(searchQuery)
                    || isbns[i].toLowerCase().contains(searchQuery)) {
                System.out.println("Title: " + titles[i]);
                System.out.println("Author: " + authors[i]);
                System.out.println("ISBN: " + isbns[i]);
                System.out.println("Availability: " + (availability[i] ? "Available" : "Not Available"));
                found = true;
            }
        }

        if (!found) {
            System.out.println("Book not found.");
        }
    }


    private void checkoutBook(Scanner scanner) {
        // book checkout functionality
        System.out.print("Enter the ISBN of the book to checkout: ");
        String isbnToCheckout = scanner.nextLine();

        boolean found = false;
        for (int i = 0; i < isbns.length; i++) {
            if (isbns[i].equals(isbnToCheckout) && availability[i]) {
                // Update availability status and inform the user
                availability[i] = false;
                System.out.println("Book with ISBN " + isbnToCheckout + " has been successfully checked out.");
                found = true;
                break;
            } else if (isbns[i].equals(isbnToCheckout) && !availability[i]) {
                // Inform the user that the book is not available for checkout
                System.out.println("Book with ISBN " + isbnToCheckout + " is not available for checkout.");
                found = true;
                break;
            }
        }

        if (!found) {
            System.out.println("Book with ISBN " + isbnToCheckout + " not found.");
        }
    }

    private void returnBook(Scanner scanner) {
        // book return functionality
        System.out.print("Enter the ISBN of the book to return: ");
        String isbnToReturn = scanner.nextLine();

        boolean found = false;
        for (int i = 0; i < isbns.length; i++) {
            if (isbns[i].equals(isbnToReturn) && !availability[i]) {
                // Update availability status and inform the user
                availability[i] = true;
                System.out.println("Book with ISBN " + isbnToReturn + " has been successfully returned.");
                found = true;
                break;
            } else if (isbns[i].equals(isbnToReturn) && availability[i]) {
                // Inform the user that the book is already in the library
                System.out.println("Book with ISBN " + isbnToReturn + " is already in the library.");
                found = true;
                break;
            }
        }

        if (!found) {
            System.out.println("Book with ISBN " + isbnToReturn + " not found.");
        }
    }

    public static void main(String[] args) {
        // Different book examples
        String[] titles = {"The Hunger Games", "To Kill a Mockingbird", "1984"};
        String[] authors = {"Suzanne Collins", "Harper Lee", "George Orwell"};
        String[] isbns = {"9780439023481", "9780061120084", "9780451524935"};
        boolean[] availability = {true, true, false};  // Set availability accordingly

        // Initializing the Library with the book examples I have given above
        Library library = new Library(titles, authors, isbns, availability);

        System.out.println("Welcome to the Library Catalog System!");
        library.run();
    }

}

